export const environment = {
  production: true,
  apiUrl: 'https://api.recantomontanhaverde.com.br',
};
