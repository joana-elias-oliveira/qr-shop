export const environment = {
  production: false,
  apiUrl: 'https://api.recantomontanhaverde.com.br',
};
