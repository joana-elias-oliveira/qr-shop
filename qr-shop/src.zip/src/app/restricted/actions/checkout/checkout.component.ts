import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CardApiService } from '../../../core/services/card-api.service';
import { FormsModule } from '@angular/forms';
import { NgFor, CurrencyPipe, NgIf } from '@angular/common';

type Product = { productName:string; unitPrice:number; quantity:number };

@Component({
  standalone:true, selector:'app-checkout', imports:[FormsModule, NgFor, CurrencyPipe, NgIf],
  template:`
  <div class="card">
    <h2>Checkout</h2>
    <p class="muted">Card: {{cardId}}</p>

    <div class="row" *ngFor="let p of products; let i = index">
      <input placeholder="Produto" [(ngModel)]="p.productName"/>
      <input type="number" min="0.01" step="0.01" placeholder="Preço" [(ngModel)]="p.unitPrice"/>
      <input type="number" min="1" step="1" placeholder="Qtd" [(ngModel)]="p.quantity"/>
      <button class="btn ghost" (click)="remove(i)">Remover</button>
    </div>
    <button class="btn ghost" (click)="add()">Adicionar item</button>

    <div class="preview" *ngIf="preview">
      <div>Total: <b>{{ preview.totalAmount | currency:'BRL':'symbol':'1.2-2':'pt-BR' }}</b></div>
      <div>Saldo atual: {{ preview.balance | currency:'BRL':'symbol' }}</div>
      <div [class.ok]="preview.sufficientBalance" [class.bad]="!preview.sufficientBalance">
        {{ preview.sufficientBalance ? 'Saldo suficiente' : 'Saldo insuficiente' }}
      </div>
    </div>

    <div class="actions">
      <button class="btn ghost" (click)="doPreview()">Pré-visualizar</button>
      <button class="btn primary" [disabled]="!preview?.sufficientBalance" (click)="doCheckout()">Confirmar compra</button>
      <button class="btn ghost" (click)="verTransacoes()" [disabled]="result===null && !preview">Ver transações</button>
    </div>

    <div class="ok" *ngIf="result !== null">Novo saldo: {{ result | currency:'BRL':'symbol' }}</div>
    <div class="bad" *ngIf="error">{{ error }}</div>
  </div>
  `,
  styles:[`
    .card{background:#fff;padding:16px;border-radius:16px;box-shadow:0 6px 20px rgba(0,0,0,.05);display:grid;gap:12px}
    .row{display:grid;grid-template-columns:1fr 120px 80px auto; gap:8px}
    input{padding:10px;border:1px solid #e2e8f0;border-radius:10px}
    .preview{background:#F7FAFC;border:1px solid #E2E8F0;padding:12px;border-radius:12px;display:grid;gap:4px}
    .actions{display:flex;gap:8px;flex-wrap:wrap}
    @media (max-width: 420px){ .row{grid-template-columns:1fr 100px 70px auto} }
  `]
})
export class CheckoutComponent {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private api = inject(CardApiService);
  cardId = decodeURIComponent(this.route.snapshot.paramMap.get('cardId') ?? '');
  products: Product[] = [{ productName:'', unitPrice:0, quantity:1 }];
  preview?: { totalAmount:number; balance:number; sufficientBalance:boolean };
  result: number | null = null; error?: string;

  add(){ this.products.push({ productName:'', unitPrice:0, quantity:1 }); }
  remove(i:number){ this.products.splice(i,1); }
  doPreview(){
    this.error = undefined; this.preview = undefined;
    this.api.checkoutPreview(this.cardId, this.products).subscribe({
      next: r => this.preview = r,
      error: e => this.error = e?.error?.message || 'Erro ao calcular total',
    });
  }
  doCheckout(){
    this.error = undefined; this.result = null;
    this.api.checkout(this.cardId, this.products).subscribe({
      next: r => { this.result = r.newBalance; },
      error: e => this.error = e?.error?.message || 'Erro ao finalizar compra',
    });
  }
  verTransacoes(){ this.router.navigate(['/transactions', encodeURIComponent(this.cardId)]); }
}
