import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CardApiService } from '../../../core/services/card-api.service';
import { FormsModule } from '@angular/forms';
import { NgIf } from '@angular/common';

@Component({
  standalone:true, selector:'app-assign-card', imports:[FormsModule, NgIf],
  template:`
  <div class="card">
    <h2>Assign Card</h2>
    <p class="muted">Card: {{cardId}}</p>
    <input placeholder="Nome completo" [(ngModel)]="name" />
    <input placeholder="CPF (apenas números)" [(ngModel)]="cpf" />
    <button class="btn primary" (click)="submit()">Assinar e vincular</button>
    <div *ngIf="signed" class="ok">Assinado: <code>{{ signed }}</code></div>
    <div *ngIf="error" class="bad">{{ error }}</div>
  </div>
  `,
  styles:[`
    .card{background:#fff;padding:16px;border-radius:16px;box-shadow:0 6px 20px rgba(0,0,0,.05);display:grid;gap:12px}
    input{padding:12px 14px;border:1px solid #e2e8f0;border-radius:12px}
    .ok{word-break:break-all}
  `]
})
export class AssignCardComponent {
  private route = inject(ActivatedRoute);
  private api = inject(CardApiService);
  cardId = decodeURIComponent(this.route.snapshot.paramMap.get('cardId') ?? '');
  name=''; cpf=''; signed?:string; error?:string;

  submit(){
    this.error = undefined; this.signed = undefined;
    this.api.assignCard(this.cardId, { name: this.name.trim(), cpf: this.cpf.trim() }).subscribe({
      next: r => this.signed = r.signedCardId,
      error: e => this.error = e?.error?.message || 'Erro ao assinar',
    });
  }
}
