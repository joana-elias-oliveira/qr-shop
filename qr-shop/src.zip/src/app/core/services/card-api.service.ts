import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CardApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl ?? 'https://api.recantomontanhaverde.com.br';

  private seg(id: string) { return encodeURIComponent(id); }

  getBalance(cardId: string) {
    return this.http.get<{ balance: number }>(`${this.base}/cards/${this.seg(cardId)}/balance`);
  }
  getTransactions(cardId: string) {
    return this.http.get<Array<{id:string;date:string;amount:number;type:'add'|'subtract';description:string}>>(
      `${this.base}/cards/${this.seg(cardId)}/transactions`
    );
  }
  assignCard(cardId: string, body: { name: string; cpf: string }) {
    return this.http.post<{ signedCardId: string }>(`${this.base}/cards/${this.seg(cardId)}/assign`, body);
  }
  addBalance(cardId: string, amount: number) {
    return this.http.post<{ newBalance: number }>(`${this.base}/cards/${this.seg(cardId)}/balance/add`, { amount });
  }
  subtractBalance(cardId: string, amount: number) {
    return this.http.post<{ newBalance: number }>(`${this.base}/cards/${this.seg(cardId)}/balance/subtract`, { amount });
  }
  checkoutPreview(cardId: string, products: { productName: string; unitPrice: number; quantity: number }[]) {
    return this.http.post<{ totalAmount:number; balance:number; sufficientBalance:boolean }>(
      `${this.base}/cards/${this.seg(cardId)}/checkout-preview`, { products }
    );
  }
  checkout(cardId: string, products: { productName: string; unitPrice: number; quantity: number }[]) {
    return this.http.post<{ newBalance:number; transaction:any }>(
      `${this.base}/cards/${this.seg(cardId)}/checkout`, { products }
    );
  }
}
